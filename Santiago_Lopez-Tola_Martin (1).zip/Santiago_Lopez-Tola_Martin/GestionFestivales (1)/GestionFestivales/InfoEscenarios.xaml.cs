﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace GestionFestivales
{
    public partial class InfoEscenarios : Window
    {
        // Lista de escenarios disponibles para mostrar información
        public List<Escenario> Escenarios { get; set; }

        // Constructor que inicializa la ventana con la lista de escenarios
        public InfoEscenarios(List<Escenario> escenarios)
        {
            InitializeComponent();

            // Asignar la lista de escenarios y configurar el selector
            Escenarios = escenarios;
            SeleccionEscenario.ItemsSource = Escenarios;
            SeleccionEscenario.DisplayMemberPath = "Nombre";
            SeleccionEscenario.SelectionChanged += SeleccionEscenario_SelectionChanged;
        }

        // Evento que se activa al cambiar la selección de escenario
        private void SeleccionEscenario_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Obtener el escenario seleccionado del selector
            var escenarioSeleccionado = SeleccionEscenario.SelectedItem as Escenario;
            if (escenarioSeleccionado != null)
            {
                // Mostrar los datos básicos del escenario
                NombreTextBox.Text = escenarioSeleccionado.Nombre;
                AforoMaximoTextBox.Text = escenarioSeleccionado.AforoMaximo.ToString();
                EntradasTextBox.Text = escenarioSeleccionado.Entradas;
                SalidasEmergenciaTextBox.Text = escenarioSeleccionado.SalidasEmergencia;
                ServiciosTextBox.Text = escenarioSeleccionado.Servicios;
                FestivalTextBox.Text = escenarioSeleccionado.Festival?.Nombre ?? "Sin asignar";

                // Cargar la foto del escenario
                try
                {
                    ImagenEscenario.Source = new BitmapImage(new Uri(escenarioSeleccionado.Foto, UriKind.RelativeOrAbsolute));
                }
                catch
                {
                    ImagenEscenario.Source = null; // Si hay un error, no mostrar imagen
                }

                // Cargar la imagen del plano
                try
                {
                    ImagenPlano.Source = new BitmapImage(new Uri(escenarioSeleccionado.Plano, UriKind.RelativeOrAbsolute));
                }
                catch
                {
                    ImagenPlano.Source = null; // Si hay un error, no mostrar imagen
                }

                // Llenar el cronograma con información de los eventos
                var eventosConArtistas = new List<dynamic>();
                foreach (var evento in escenarioSeleccionado.Eventos)
                {
                    string artistaNombre = evento.Artista != null ? evento.Artista.Nombre : "Sin asignar";

                    eventosConArtistas.Add(new
                    {
                        Dia = evento.Dia,
                        Hora = evento.Hora,
                        Artista = artistaNombre
                    });
                }

                // Enlazar los eventos con el DataGrid para mostrarlos
                CronogramaDataGrid.ItemsSource = eventosConArtistas;
            }
        }

        // Maneja el evento del botón para cerrar la ventana
        private void Volver_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}