﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace GestionFestivales
{
    public partial class InfoFestivales : Window
    {
        // Lista que almacena los festivales disponibles
        public List<Festival> Festivales { get; set; }

        // Constructor de la clase, recibe la lista de festivales como parámetro
        public InfoFestivales(List<Festival> festivales)
        {
            InitializeComponent(); // Inicializa los componentes visuales de la ventana

            Festivales = festivales; // Asigna la lista de festivales al atributo local

            // Configura el ComboBox para mostrar los nombres de los festivales
            SeleccionFestival.ItemsSource = Festivales;
            SeleccionFestival.DisplayMemberPath = "Nombre"; // Indica que se debe mostrar el nombre de cada festival

            // Asocia un evento para manejar el cambio de selección en el ComboBox
            SeleccionFestival.SelectionChanged += SeleccionFestival_SelectionChanged;
        }

        // Evento que se ejecuta cuando se selecciona un festival en el ComboBox
        private void SeleccionFestival_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Obtiene el festival seleccionado del ComboBox
            var festivalSeleccionado = SeleccionFestival.SelectedItem as Festival;

            // Comprueba si hay un festival seleccionado
            if (festivalSeleccionado != null)
            {
                // Rellena los campos con la información general del festival
                NombreTextBox.Text = festivalSeleccionado.Nombre;
                FechaTextBox.Text = festivalSeleccionado.Fecha.ToString("dd/MM/yyyy"); // Formato de fecha legible
                UbicacionTextBox.Text = festivalSeleccionado.Ubicacion;
                EstadoTextBox.Text = festivalSeleccionado.Estado;

                // Rellena los campos con la información adicional del festival
                RedesSocialesTextBox.Text = festivalSeleccionado.RedesSociales;
                PrecioEntradasTextBox.Text = $"{festivalSeleccionado.PrecioEntradas:C}"; // Formatea el precio como moneda
                EdicionTextBox.Text = festivalSeleccionado.Edicion;
                VideosPromocionalesTextBox.Text = festivalSeleccionado.VideosPromocionales;
                OrganizadoresTextBox.Text = festivalSeleccionado.Organizadores;
                NormasTextBox.Text = festivalSeleccionado.Normas;
                ComoLlegarTextBox.Text = festivalSeleccionado.ComoLlegar;
                DondeDormirTextBox.Text = festivalSeleccionado.DondeDormir;

                // Intenta cargar y mostrar la imagen del festival
                try
                {
                    ImagenFestival.Source = new BitmapImage(new Uri(festivalSeleccionado.Foto, UriKind.RelativeOrAbsolute));
                }
                catch
                {
                    ImagenFestival.Source = null; // Si ocurre un error, no muestra ninguna imagen
                }

                // Rellena la tabla de artistas con la información de los artistas del festival
                var artistasDelFestival = festivalSeleccionado.Artistas.Select(artista => new
                {
                    Nombre = artista.Nombre, // Nombre del artista
                    Género = artista.Género, // Género musical del artista
                    DiaActuación = artista.DiaActuación // Día en que actuará
                }).ToList();

                // Asigna la lista de artistas al DataGrid para mostrarlos en la tabla
                ListadoArtistasDataGrid.ItemsSource = artistasDelFestival;
            }
        }

        // Evento para manejar el clic en el botón "Volver"
        private void Volver_Click(object sender, RoutedEventArgs e)
        {
            this.Close(); // Cierra la ventana actual y regresa a la ventana anterior
        }
    }
}


