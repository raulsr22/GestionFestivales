﻿using System.Collections.Generic; 
using System; 
using System.Windows; 

namespace GestionFestivales
{
    public partial class GestionFestivalesWindow : Window
    {
        // Propiedades privadas para almacenar información del usuario actual.
        private string nombreUsuario;
        private string apellidosUsuario;
        private string fotoUsuario;
        private DateTime horaUltimoAcceso;

        // Lista pública para almacenar los festivales gestionados.
        public List<Festival> Festivales { get; set; }

        // Constructor de la ventana de gestión de festivales. Recibe datos del usuario y la hora de acceso.
        public GestionFestivalesWindow(string nombre, string apellidos, string foto, DateTime ultimaHoraAcceso)
        {
            InitializeComponent(); // Inicializa los componentes de la interfaz.

            // Asignar los valores del usuario a las propiedades privadas.
            nombreUsuario = nombre;
            apellidosUsuario = apellidos;
            fotoUsuario = foto;
            horaUltimoAcceso = ultimaHoraAcceso;

            // Lista de artistas predeterminados con información básica.
            var artistas = new List<Artista>
            {
                new Artista
                {
                    Nombre = "Rosalía",
                    Género = "Pop-Español",
                    DiaActuación = "07/08/2025",
                    Contacto = "rosaliacontact@gmail.com",
                    Foto = "Resources/rosalia.jpg"
                },
                new Artista
                {
                    Nombre = "Vetusta Morla",
                    Género = "Indie Rock",
                    DiaActuación = "01/05/2025",
                    Contacto = "vetustamorla@gmail.com",
                    Foto = "Resources/vetusta.jpg"
                },
                new Artista
                {
                    Nombre = "Paco de Lucía Tributo",
                    Género = "Flamenco",
                    DiaActuación = "10/07/2025",
                    Contacto = "pacodeluciatributo@gmail.com",
                    Foto = "Resources/pacodelucia.jpg"
                }
            };

            // Lista de festivales con información detallada, incluyendo los artistas asociados.
            Festivales = new List<Festival>
            {
                new Festival
                {
                    Nombre = "Viña Rock",
                    Fecha = DateTime.Parse("2025-05-01"),
                    Ubicacion = "Villarrobledo, Albacete",
                    Estado = "Planificado",
                    RedesSociales = "https://www.vina-rock.com/",
                    PrecioEntradas = 60m,
                    Edicion = "Edición 2025",
                    VideosPromocionales = "https://youtu.be/pOzLltwAKQU?si=CLUk50tB2VP0aMTw",
                    Organizadores = "Ayuntamiento de Villarrobledo y entidades colaboradoras",
                    Normas = "Prohibido el acceso con vidrio, respetar las zonas de acampada.",
                    ComoLlegar = "Trenes directos a Villarrobledo, buses organizados desde toda España.",
                    DondeDormir = "Zona de acampada oficial y hoteles cercanos.",
                    Foto = "Resources/viñaRock.jpg",
                    Artistas = new List<Artista> { artistas[1] } // Asocia Vetusta Morla.
                },
                new Festival
                {
                    Nombre = "Medusa Festival",
                    Fecha = DateTime.Parse("2025-08-07"),
                    Ubicacion = "Playa de Cullera, Valencia",
                    Estado = "Planificado",
                    RedesSociales = "https://www.medusasunbeach.com",
                    PrecioEntradas = 85.95m,
                    Edicion = "Edición 2025",
                    VideosPromocionales = "https://youtu.be/T5p4YftuI9g?si=eSZgRoOq-EaX49yO",
                    Organizadores = "Medusa Sunbeach Festival Organization",
                    Normas = "Acceso permitido al festival con abono General y Supervip para mayores de 16 años. La acampada es sólo para mayores de 18 años.",
                    ComoLlegar = "Trenes directos a Cullera, autobuses organizados desde distintas zonas de España.",
                    DondeDormir = "Zona de acampada oficial y opciones de Glamping; hoteles y apartamentos en Cullera.",
                    Foto = "Resources/medusa.png",
                    Artistas = new List<Artista> { artistas[0] } // Asocia Rosalía.
                },
                new Festival
                {
                    Nombre = "Madcool Festival",
                    Fecha = DateTime.Parse("2025-07-10"),
                    Ubicacion = "Madrid",
                    Estado = "Planificado",
                    RedesSociales = "https://madcoolfestival.es",
                    PrecioEntradas = 199.00m,
                    Edicion = "Edición 2025",
                    VideosPromocionales = "https://youtu.be/CuvMVb02NnM?si=kbAsO_Ukp9KF59-q",
                    Organizadores = "Madcool Organization",
                    Normas = "Prohibido introducir comida o bebida del exterior; seguir las indicaciones del personal de seguridad.",
                    ComoLlegar = "Trenes y metro hasta IFEMA, autobuses organizados desde distintos puntos de Madrid.",
                    DondeDormir = "Hoteles cercanos al recinto y opciones de alojamiento en Madrid.",
                    Foto = "Resources/madcoolFestival.jpg",
                    Artistas = new List<Artista> { artistas[2] } // Asocia Paco de Lucía Tributo.
                }
            };

            // Establecer la lista de festivales como fuente de datos para el DataGrid.
            FestivalesDataGrid.ItemsSource = Festivales;
        }

        // Método para agregar un nuevo festival a la lista.
        private void AgregarFestival_Click(object sender, RoutedEventArgs e)
        {
            var nuevoFestival = new Festival
            {
                Nombre = "Nuevo Festival",
                Fecha = DateTime.Now,
                Ubicacion = "Ubicación por definir",
                Estado = "Planificado",
                RedesSociales = "No definido",
                PrecioEntradas = 0,
                Edicion = "Nueva Edición",
                VideosPromocionales = "No disponible",
                Organizadores = "No definido",
                Normas = "No definido",
                ComoLlegar = "No definido",
                DondeDormir = "No definido",
                Artistas = new List<Artista>()
            };

            Festivales.Add(nuevoFestival); // Añade el nuevo festival a la lista.
            FestivalesDataGrid.Items.Refresh(); // Refresca el DataGrid para mostrar los cambios.
            MessageBox.Show("Festival agregado correctamente.", "Agregar Festival", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        // Método para abrir una ventana con información detallada de los festivales.
        private void AbrirInfoFestivales_Click(object sender, RoutedEventArgs e)
        {
            InfoFestivales infoFestivalesWindow = new InfoFestivales(Festivales); // Crea una nueva ventana.
            infoFestivalesWindow.ShowDialog(); // Muestra la ventana en modo modal.
        }

        // Método para volver al menú principal.
        private void Volver_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow(nombreUsuario, apellidosUsuario, fotoUsuario, horaUltimoAcceso); // Crea una nueva instancia de la ventana principal.
            mainWindow.Show(); // Muestra la ventana principal.
            this.Close(); // Cierra la ventana actual.
        }

        // Método para mostrar ayuda sobre la gestión de festivales.
        private void Ayuda_Click(object sender, RoutedEventArgs e)
        {
            string ayuda = "Gestión de Festivales:\n\n" +
                           "- Puedes agregar un nuevo festival utilizando el botón 'Agregar Festival'.\n" +
                           "- Ingresa los detalles como Nombre, Fecha y Ubicación del festival.\n" +
                           "- Utiliza el botón 'Información' para ver detalles del festival.\n\n" +
                           "Usa el botón 'Volver' para regresar al menú principal.";
            MessageBox.Show(ayuda, "Ayuda", MessageBoxButton.OK, MessageBoxImage.Information); // Muestra un mensaje con las instrucciones.
        }
    }
}

