﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace GestionFestivales
{
    public partial class LoginWindow : Window
    {
        // Diccionario que almacena usuarios y datos asociados
        // Cada usuario tiene contraseña, nombre, apellidos, correo y foto de perfil
        private Dictionary<string, (string Password, string Nombre, string Apellidos, string Correo, string Foto)> usuarios =
            new Dictionary<string, (string, string, string, string, string)>
            {
                { "Eduardo", ("ipo1", "Eduardo", "Martín Muñoz", "eduardo.martin11@alu.uclm.es", "FotosUsuarios/Eduardo.jpeg") },
                { "Raúl", ("ipo1", "Raúl", "Santiago Roldán", "Raul.Santiago1@alu.uclm.es", "FotosUsuarios/Raúl1.jpeg") },
                { "Álvaro", ("ipo1", "Álvaro", "López-Tola Rodríguez", "alvaro.lopez40@alu.uclm.es", "FotosUsuarios/Álvaro.jpeg") }
            };

        // Variable para alternar la visibilidad de la contraseña
        private bool mostrarContraseña = false;

        public LoginWindow()
        {
            InitializeComponent();
        }

        // Evento para manejar el botón "Acceder"
        private void Acceder_Click(object sender, RoutedEventArgs e)
        {
            // Obtener datos ingresados por el usuario
            string usuarioIngresado = txtUsuario.Text;
            string passwordIngresada = mostrarContraseña ? txtPassword.Text : pwdPassword.Password;

            // Validar si el usuario existe
            if (usuarios.ContainsKey(usuarioIngresado))
            {
                var datos = usuarios[usuarioIngresado]; // Obtener los datos del usuario
                if (datos.Password == passwordIngresada) // Validar contraseña
                {
                    // Extraer los datos del usuario autenticado
                    string nombre = datos.Nombre;
                    string apellidos = datos.Apellidos;
                    string foto = datos.Foto;
                    DateTime horaUltimoAcceso = DateTime.Now; // Guardar la hora de acceso

                    // Abrir la ventana principal (MainWindow) con los datos del usuario
                    MainWindow mainWindow = new MainWindow(nombre, apellidos, foto, horaUltimoAcceso);
                    mainWindow.Show();
                    this.Close(); // Cerrar la ventana de login
                }
                else
                {
                    // Mensaje de error si la contraseña es incorrecta
                    MessageBox.Show("Contraseña incorrecta.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                // Mensaje de error si el usuario no existe
                MessageBox.Show("Usuario no encontrado.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Evento para alternar la visibilidad de la contraseña
        private void MostrarContraseña_Click(object sender, RoutedEventArgs e)
        {
            // Cambiar el estado de visibilidad
            mostrarContraseña = !mostrarContraseña;

            if (mostrarContraseña)
            {
                // Mostrar contraseña en un TextBox
                txtPassword.Text = pwdPassword.Password;
                txtPassword.Visibility = Visibility.Visible;
                pwdPassword.Visibility = Visibility.Collapsed;
            }
            else
            {
                // Volver a ocultar la contraseña en un PasswordBox
                pwdPassword.Password = txtPassword.Text;
                pwdPassword.Visibility = Visibility.Visible;
                txtPassword.Visibility = Visibility.Collapsed;
            }
        }
    }
}
