﻿using System.Collections.Generic;

namespace GestionFestivales
{
    /// Clase que representa a un Artista dentro del sistema de gestión de festivales.
    /// Contiene información personal, profesional y de actuación.
    public class Artista
    {
        // Información básica del artista
        public string Nombre { get; set; } // Nombre del artista o grupo
        public string Género { get; set; } // Género musical
        public string Contacto { get; set; } // Correo o contacto del artista
        public double Caché { get; set; } // Caché del artista
        public string DiaActuación { get; set; } // Día en que actuará
        public string Foto { get; set; } // Ruta o URL de la imagen del artista

        // Información descriptiva
        public string Descripción { get; set; } // Breve descripción del artista
        public string Ubicación { get; set; } // Lugar de residencia del artista
        public string Teléfono { get; set; } // Número de teléfono de contacto

        // Propiedades adicionales
        public bool Estado { get; set; } // Indica si el artista está activo o inactivo
        public string Biografía { get; set; } // Detalles biográficos del artista
        public string Trayectoria { get; set; } // Logros y experiencias previas
        public string Premios { get; set; } // Premios obtenidos por el artista
        public string Integrantes { get; set; } // Miembros del grupo (si aplica)
        public string PeticionesEspeciales { get; set; } // Requisitos específicos del artista (catering, etc.)

        // Relaciones con otras entidades del sistema
        public Festival Festival { get; set; } // Festival al que está asociado el artista
        public Escenario Escenario { get; set; } // Escenario donde actuará el artista
    }
}



