﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace GestionFestivales
{
    public partial class GestionArtistasWindow : Window
    {
        // Lista de artistas
        public List<Artista> Artistas { get; set; }

        // Información del usuario
        private string nombreUsuario;
        private string apellidosUsuario;
        private string fotoUsuario;
        private DateTime horaUltimoAcceso;

        // Constructor de la ventana
        public GestionArtistasWindow(string nombre, string apellidos, string foto, DateTime horaAcceso, List<Festival> festivales, List<Escenario> escenarios)
        {
            InitializeComponent();

            // Guardamos los datos del usuario
            nombreUsuario = nombre;
            apellidosUsuario = apellidos;
            fotoUsuario = foto;
            horaUltimoAcceso = horaAcceso;

            // Creamos datos de prueba para la lista de artistas
            Artistas = new List<Artista>
            {
                new Artista
                {
                    Nombre = "Rosalía",
                    Género = "Pop-Español",
                    Caché = 60000,
                    Contacto = "rosaliacontact@gmail.com",
                    DiaActuación = "19/08/2025",
                    Estado = true,
                    Foto = "/Resources/rosalia.jpg",
                    Descripción = "Mejor artista del flamenco-pop",
                    Teléfono = "633556890",
                    Biografía = "Cantante y compositora española con varios premios Grammy.",
                    Trayectoria = "Álbumes como 'El Mal Querer'.",
                    Premios = "5 Grammy Latinos, 1 Grammy.",
                    Integrantes = "Solista.",
                    PeticionesEspeciales = "Catering vegano y zona de descanso privada.",
                    Festival = festivales.FirstOrDefault(f => f.Nombre == "Medusa Festival"),
                    Escenario = escenarios.FirstOrDefault(e => e.Nombre == "Escenario Principal")
                },
                new Artista
                {
                    Nombre = "Vetusta Morla",
                    Género = "Indie Rock",
                    Caché = 25000,
                    Contacto = "vetustamorla@gmail.com",
                    Descripción = "Banda icónica del indie español.",
                    DiaActuación = "22/08/2025",
                    Foto = "/Resources/vm.jpg",
                    Teléfono = "645890012",
                    Biografía = "Banda originaria de Tres Cantos, Madrid, con una carrera de más de 20 años.",
                    Trayectoria = "Álbumes como 'Mapas' y 'La Deriva'.",
                    Premios = "2 Premios de la Música Independiente.",
                    Integrantes = "Pucho, David, Álvaro, Jorge, Guillermo, Juanma.",
                    PeticionesEspeciales = "Pantalla LED personalizada y camerinos insonorizados.",
                    Festival = festivales.FirstOrDefault(f => f.Nombre == "Viña Rock"),
                    Escenario = escenarios.FirstOrDefault(e => e.Nombre == "Escenario Secundario")
                },
                new Artista
                {
                    Nombre = "Paco de Lucía Tributo",
                    Género = "Flamenco",
                    Caché = 20000,
                    Contacto = "pacodeluciatributo@gmail.com",
                    Descripción = "Homenaje al maestro del flamenco español",
                    DiaActuación = "23/08/2025",
                    Foto = "/Resources/pdl.jpg",
                    Teléfono = "690554132",
                    Biografía = "Tributo a Paco de Lucía, con una banda de músicos experimentados.",
                    Trayectoria = "Espectáculos en múltiples festivales flamencos en España y Europa.",
                    Premios = "Reconocimiento especial en el Festival Flamenco de Jerez.",
                    Integrantes = "Guitarristas: Juan García y Luis Romero. Percusión: María López.",
                    PeticionesEspeciales = "Guitarras de reserva y ajustes personalizados en el sonido.",
                    Festival = festivales.FirstOrDefault(f => f.Nombre == "Madcool Festival"),
                    Escenario = escenarios.FirstOrDefault(e => e.Nombre == "Escenario Principal")
                }
            };

            // Enlazar la lista de artistas al DataGrid
            ArtistasDataGrid.ItemsSource = Artistas;
        }

        // Evento para manejar cambios en la selección del DataGrid
        private void ArtistasDataGrid_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            // Método vacío, puede ser implementado para manejar lógica adicional
        }

        // Método para agregar un nuevo artista
        private void AgregarArtista_Click(object sender, RoutedEventArgs e)
        {
            // Crear un nuevo artista con valores predeterminados
            var nuevoArtista = new Artista
            {
                Nombre = "Nuevo Artista",
                DiaActuación = "2024-01-01",
                Contacto = "nuevo@gmail.com",
                Género = "Género musical",
                Foto = "/Resources/default.jpg",
                Descripción = "Nueva descripción"
            };

            // Agregar el artista a la lista y actualizar la tabla
            Artistas.Add(nuevoArtista);
            ArtistasDataGrid.Items.Refresh();

            // Mostrar mensaje de confirmación
            MessageBox.Show("Artista agregado correctamente.", "Agregar Artista", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        // Método para regresar a la ventana principal
        private void Volver_Click(object sender, RoutedEventArgs e)
        {
            // Creamos la instancia de la ventana principal y pasar datos del usuario
            MainWindow mainWindow = new MainWindow(nombreUsuario, apellidosUsuario, fotoUsuario, horaUltimoAcceso);
            mainWindow.Show();

            // Cerrar la ventana actual
            this.Close();
        }

        // Método para mostrar el cuadro de ayuda
        private void Ayuda_Click(object sender, RoutedEventArgs e)
        {
            string ayuda = "Gestión de Artistas:\n\n" +
                           "- Puedes agregar un nuevo artista utilizando el botón 'Agregar Artista'.\n" +
                           "- Completa los detalles necesarios como Nombre, Género, Contacto, etc.\n" +
                           "- Usa el botón 'Volver' para regresar al menú principal.";
            MessageBox.Show(ayuda, "Ayuda", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        // Método para abrir la ventana de información detallada de artistas
        private void AbrirInfoArtistas_Click(object sender, RoutedEventArgs e)
        {
            // Creamos la  instancia de la ventana de información y pasar la lista de artistas
            var infoArtistasWindow = new InfoArtistas(Artistas);
            infoArtistasWindow.ShowDialog();
        }
    }
}




