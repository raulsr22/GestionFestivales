﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace GestionFestivales
{
    public partial class GestionEscenariosWindow : Window
    {
        // Variables privadas para almacenar información de los usuarios
        private string nombreUsuario;
        private string apellidosUsuario;
        private string fotoUsuario;
        private DateTime horaUltimoAcceso;

        // Listas públicas para manejar escenarios y festivales
        public List<Escenario> Escenarios { get; set; }
        public List<Festival> Festivales { get; set; }

        // Constructor que inicializa la ventana con los datos proporcionados
        public GestionEscenariosWindow(string nombre, string apellidos, string foto, DateTime ultimaHoraAcceso, List<Festival> festivales, List<Escenario> escenarios)
        {
            InitializeComponent();

            // Asignamos parámetros a variables locales
            nombreUsuario = nombre;
            apellidosUsuario = apellidos;
            fotoUsuario = foto;
            horaUltimoAcceso = ultimaHoraAcceso;
            Festivales = festivales;
            Escenarios = escenarios;

            // Enlazamos la lista de escenarios con el DataGrid
            EscenariosDataGrid.ItemsSource = Escenarios;
        }

        // Manejo el evento del botón mostrar información de los escenarios
        private void AbrirInfoEscenarios_Click(object sender, RoutedEventArgs e)
        {
            // Inicializar festivales y artistas si no están ya definidos
            var festival1 = new Festival { Nombre = "Viña Rock" };
            var festival2 = new Festival { Nombre = "MadCool Festival" };
            var artista1 = new Artista { Nombre = "Vetusta Morla" };
            var artista2 = new Artista { Nombre = "Rosalía" };
            var artista3 = new Artista { Nombre = "Paco de Lucía Tributo" };

            // Creamos escenarios con datos de ejemplo
            Escenarios = new List<Escenario>
            {
                new Escenario
                {
                    Nombre = "Escenario Principal",
                    AforoMaximo = 5000,
                    Entradas = "2 entradas principales",
                    SalidasEmergencia = "4 salidas de emergencia",
                    Servicios = "Servicios médicos, aseos, seguridad",
                    Foto = "Resources/EscenarioPrincipal.jpg",
                    Plano = "Resources/Plano.jpeg",
                    Festival = festival1, // Asignación del festival
                    Eventos = new List<Evento>
                    {
                        new Evento { Dia = "19/08/2025", Hora = "18:00", Artista = artista2 },
                        new Evento { Dia = "19/08/2025", Hora = "20:00", Artista = artista1 }
                    }
                },
                new Escenario
                {
                    Nombre = "Escenario Secundario",
                    AforoMaximo = 2000,
                    Entradas = "1 entrada principal",
                    SalidasEmergencia = "2 salidas de emergencia",
                    Servicios = "Aseos, seguridad",
                    Foto = "Resources/EscenarioSecundario.jpg",
                    Plano = "Resources/Plano.jpeg",
                    Festival = festival2, // Asignación del festival
                    Eventos = new List<Evento>
                    {
                        new Evento { Dia = "20/08/2025", Hora = "19:00", Artista = artista3 }
                    }
                }
            };

            // Crear y mostrar la ventana InfoEscenarios
            var infoEscenariosWindow = new InfoEscenarios(Escenarios);
            infoEscenariosWindow.ShowDialog();
        }

        // Maneja el evento del botón para agregar un nuevo escenario
        private void AgregarEscenario_Click(object sender, RoutedEventArgs e)
        {
            // Crear un escenario nuevo con valores predeterminados
            var nuevoEscenario = new Escenario
            {
                Nombre = "Nuevo Escenario",
                AforoMaximo = 1000,
                Entradas = "1 entrada principal",
                SalidasEmergencia = "1 salida de emergencia",
                Servicios = "Servicios básicos",
                Foto = "Resources/default.jpg",
                Plano = "Resources/default_plano.jpg",
                Festival = Festivales.FirstOrDefault(), // Asignar el primer festival disponible
                Eventos = new List<Evento>()
            };

            // Añadir el nuevo escenario a la lista y actualizar el DataGrid
            Escenarios.Add(nuevoEscenario);
            EscenariosDataGrid.Items.Refresh();
            // Mostramos un mensaje de confirmación
            MessageBox.Show("Escenario agregado correctamente.", "Agregar Escenario", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        // Maneja el evento del botón para volver a la ventana principal
        private void Volver_Click(object sender, RoutedEventArgs e)
        {
            // Crear una instancia de la ventana principal y cierra la actual
            MainWindow mainWindow = new MainWindow(nombreUsuario, apellidosUsuario, fotoUsuario, horaUltimoAcceso);
            mainWindow.Show();
            this.Close();
        }

        // Maneja el evento del botón para mostrar ayuda
        private void Ayuda_Click(object sender, RoutedEventArgs e)
        {
            // Mensaje de ayuda con información detallada sobre la gestión de escenarios
            string ayuda = "Gestión de Escenarios:\n\n" +
                           "- Puedes agregar un nuevo escenario utilizando el botón 'Agregar Escenario'.\n" +
                           "- Completa los detalles como Nombre, Aforo Máximo, Servicios, etc.\n" +
                           "- Asegúrate de revisar los datos antes de agregarlos.\n" +
                           "- Dispones de un botón de Información para más detalles sobre los Artistas. \n\n" +
                           "Usa el botón 'Volver' para regresar al menú principal.";
            MessageBox.Show(ayuda, "Ayuda", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}