﻿using System.Collections.Generic;

namespace GestionFestivales
{
    public class Escenario
    {
        public string Nombre { get; set; } // Nombre del escenario
        public int AforoMaximo { get; set; } // Capacidad máxima del escenario
        public string Entradas { get; set; } // Descripción de las entradas al escenario
        public string SalidasEmergencia { get; set; } // Descripción de las salidas de emergencia
        public string Servicios { get; set; } // Lista de servicios disponibles (aseos, seguridad, etc.)
        public string Foto { get; set; } // Ruta a la foto descriptiva del escenario
        public string Plano { get; set; } // Ruta al plano gráfico del escenario
        public Festival Festival { get; set; }// Nombre del festival asociado al escenario

        public List<Evento> Eventos { get; set; } // Lista de eventos asociados al escenario
    }

    public class Evento
    {
        public string Dia { get; set; } // Día del evento
        public string Hora { get; set; } // Hora del evento
        public Artista Artista { get; set; } // Asociar el evento con un artista
    }
}


