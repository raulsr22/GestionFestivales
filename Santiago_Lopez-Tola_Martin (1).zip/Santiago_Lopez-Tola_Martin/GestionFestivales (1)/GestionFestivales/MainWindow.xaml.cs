﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media.Imaging;
using System.Linq;


namespace GestionFestivales
{
    public partial class MainWindow : Window
    {
        // Variables para almacenar los datos del usuario
        private string nombreUsuario;
        private string apellidosUsuario;
        private string fotoUsuario;
        private DateTime horaUltimoAcceso;
        private List<Festival> Festivales;
        private List<Escenario> Escenarios;
        

        // Constructor que recibe los datos del usuario
        public MainWindow(string nombre, string apellidos, string foto, DateTime ultimaHoraAcceso)
        {
            InitializeComponent();

            // Almacenar los datos del usuario
            nombreUsuario = nombre;
            apellidosUsuario = apellidos;
            fotoUsuario = foto;
            horaUltimoAcceso = ultimaHoraAcceso;

            // Inicializar Festivales
            Festivales = new List<Festival>
        {
            new Festival
            {
                Nombre = "Viña Rock",
                Fecha = DateTime.Parse("2025-05-01"),
                Ubicacion = "Villarrobledo, Albacete",
                Estado = "Planificado",
                RedesSociales = "https://www.vina-rock.com/",
                PrecioEntradas = 60m,
                Edicion = "Edición 2025",
                VideosPromocionales = "https://youtu.be/pOzLltwAKQU?si=CLUk50tB2VP0aMTw",
                Organizadores = "Ayuntamiento de Villarrobledo y entidades colaboradoras",
                Normas = "Prohibido el acceso con vidrio, respetar las zonas de acampada",
                ComoLlegar = "Trenes directos a Villarrobledo, buses organizados desde toda España",
                DondeDormir = "Zona de acampada oficial y hoteles cercanos",
                Foto = "Resources/viñaRock.jpg"
            },
            new Festival
            {
                Nombre = "Medusa Festival",
                Fecha = DateTime.Parse("2025-08-07"),
                Ubicacion = "Playa de Cullera, Valencia",
                Estado = "Planificado",
                RedesSociales = "https://www.medusasunbeach.com",
                PrecioEntradas = 85.95m,
                Edicion = "Edición 2025",
                VideosPromocionales = "https://youtu.be/T5p4YftuI9g?si=eSZgRoOq-EaX49yO",
                Organizadores = "Medusa Sunbeach Festival Organization",
                Normas = "Acceso permitido al festival con abono General y Supervip para mayores de 16 años. La acampada es sólo para mayores de 18 años.",
                ComoLlegar = "Trenes directos a Cullera, autobuses organizados desde distintas zonas de España.",
                DondeDormir = "Zona de acampada oficial y opciones de Glamping; hoteles y apartamentos en Cullera.",
                Foto = "Resources/medusa.png"
            },
            new Festival
            {
                Nombre = "Madcool Festival",
                Fecha = DateTime.Parse("2025-07-10"),
                Ubicacion = "Madrid",
                Estado = "Planificado",
                RedesSociales = "https://madcoolfestival.es",
                PrecioEntradas = 199.00m,
                Edicion = "Edición 2025",
                VideosPromocionales = "https://youtu.be/CuvMVb02NnM?si=kbAsO_Ukp9KF59-q",
                Organizadores = "Madcool Organization",
                Normas = "Prohibido introducir comida o bebida del exterior; seguir las indicaciones del personal de seguridad.",
                ComoLlegar = "Trenes y metro hasta IFEMA, autobuses organizados desde distintos puntos de Madrid.",
                DondeDormir = "Hoteles cercanos al recinto y opciones de alojamiento en Madrid.",
                Foto = "Resources/madcoolFestival.jpg"
            }
        };

            // Inicializar lista de escenarios
            Escenarios = new List<Escenario>
    {
        new Escenario
        {
        
                    Nombre = "Escenario Principal",
                    AforoMaximo = 5000,
                    Entradas = "2 entradas principales",
                    SalidasEmergencia = "4 salidas de emergencia",
                    Servicios = "Servicios médicos, aseos, seguridad",
                    Foto = "Resources/EscenarioPrincipal.jpg",
                    Plano = "Resources/PlanoPrincipal.jpg",
                    Festival = Festivales.FirstOrDefault(f => f.Nombre == "Viña Rock"), // Asignación del festival
                    Eventos = new List<Evento>
                    {
                        new Evento { Dia = "19/08/2025", Hora = "18:00", Artista = Festivales.FirstOrDefault(f => f.Nombre == "Medusa Festival")?.Artistas.FirstOrDefault(a => a.Nombre == "Rosalía") },
                        new Evento { Dia = "19/08/2025", Hora = "20:00", Artista = Festivales.FirstOrDefault(f => f.Nombre == "Viña Rock")?.Artistas.FirstOrDefault(a => a.Nombre == "Vetusta Morla") }
                    }
                },
      
      new Escenario
                {
                    Nombre = "Escenario Secundario",
                    AforoMaximo = 2000,
                    Entradas = "1 entrada principal",
                    SalidasEmergencia = "2 salidas de emergencia",
                    Servicios = "Aseos, seguridad",
                    Foto = "Resources/EscenarioSecundario.jpg",
                    Plano = "Resources/PlanoSecundario.jpg",
                    Festival = Festivales.FirstOrDefault(f => f.Nombre == "MadCool Festival"), // Asignación del festival
                    Eventos = new List<Evento>
                    {
                        new Evento { Dia = "20/08/2025", Hora = "19:00", Artista = Festivales.FirstOrDefault(f => f.Nombre == "MadCool Festival")?.Artistas.FirstOrDefault(a => a.Nombre == "Paco de Lucía Tributo") }
                    }
                }
    };

            // Mostrar la foto del usuario
            try
            {
                imgUsuario.Source = new BitmapImage(new Uri(fotoUsuario, UriKind.RelativeOrAbsolute));
            }
            catch (Exception)
            {
                imgUsuario.Source = new BitmapImage(new Uri("Resources/default_user.png", UriKind.Relative));
            }

            // Mostrar el nombre y la última hora de acceso
            txtNombre.Text = $"{nombreUsuario} {apellidosUsuario}";
            txtUltimoAcceso.Text = $"Último acceso: {horaUltimoAcceso:g}";
        }

        private void Festivales_Click(object sender, RoutedEventArgs e)
        {
            // Pasar los datos del usuario a la ventana de Festivales
            GestionFestivalesWindow gestionFestivalesWindow = new GestionFestivalesWindow(nombreUsuario, apellidosUsuario, fotoUsuario, horaUltimoAcceso);
            gestionFestivalesWindow.Show();
            this.Close();
        }

        private void Artistas_Click(object sender, RoutedEventArgs e)
        {
            // Pasar los datos del usuario a la ventana de Artistas
            GestionArtistasWindow gestionArtistasWindow = new GestionArtistasWindow(nombreUsuario, apellidosUsuario, fotoUsuario, horaUltimoAcceso, Festivales, Escenarios);
            gestionArtistasWindow.Show();
            this.Close();
        }

        private void Escenarios_Click(object sender, RoutedEventArgs e)
        {
            // Pasar los datos del usuario a la ventana de Escenarios
            GestionEscenariosWindow gestionEscenariosWindow = new GestionEscenariosWindow(nombreUsuario, apellidosUsuario, fotoUsuario, horaUltimoAcceso, Festivales, Escenarios);
            gestionEscenariosWindow.Show();
            this.Close();
        }

        private void CerrarSesion_Click(object sender, RoutedEventArgs e)
        {
            // Volver a la ventana de Login
            LoginWindow loginWindow = new LoginWindow();
            loginWindow.Show();
            this.Close();
        }

        private void Ayuda_Click(object sender, RoutedEventArgs e)
        {
            string ayuda = "Bienvenido a la Gestión de Festivales.\n\n" +
                           "Esta aplicación permite gestionar los siguientes elementos:\n" +
                           "- Festivales: puedes agregar nuevos festivales.\n" +
                           "- Artistas: puedes agregar nuevos artistas.\n" +
                           "- Escenarios: puedes agregar nuevos escenarios.\n\n" +
                           "Utiliza los botones correspondientes para navegar por las opciones. " +
                           "Para volver al menú principal, usa el botón 'Volver'.";
            MessageBox.Show(ayuda, "Ayuda", MessageBoxButton.OK, MessageBoxImage.Information);
        }

    }
}
