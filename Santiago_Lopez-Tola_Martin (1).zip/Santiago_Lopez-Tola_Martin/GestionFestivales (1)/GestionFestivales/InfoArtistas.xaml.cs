﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace GestionFestivales
{
    public partial class InfoArtistas : Window
    {
        // Propiedad que almacena la lista de artistas
        public List<Artista> Artistas { get; set; }

        // Constructor que recibe la lista de artistas
        public InfoArtistas(List<Artista> artistas)
        {
            InitializeComponent();

            // Asignamos la lista de artistas al ComboBox para la selección
            Artistas = artistas;
            SeleccionArtista.ItemsSource = Artistas; // Enlazamos los datos al ComboBox
            SeleccionArtista.DisplayMemberPath = "Nombre"; // Mostramos el nombre de cada artista
            SeleccionArtista.SelectionChanged += SeleccionArtista_SelectionChanged; // Evento al cambiar selección
        }

        // Evento que se ejecuta cuando se selecciona un artista en el ComboBox
        private void SeleccionArtista_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Obtenemos el artista seleccionado
            var artistaSeleccionado = SeleccionArtista.SelectedItem as Artista;
            if (artistaSeleccionado != null)
            {
                // Actualizamos los campos de texto con la información del artista seleccionado
                NombreTextBox.Text = artistaSeleccionado.Nombre;
                GeneroTextBox.Text = artistaSeleccionado.Género;
                CorreoTextBox.Text = artistaSeleccionado.Contacto;
                CacheTextBox.Text = artistaSeleccionado.Caché.ToString("F2"); // Formateamos el caché a 2 decimales
                DiaActuacionDatePicker.SelectedDate = DateTime.TryParse(artistaSeleccionado.DiaActuación, out var fecha)
                    ? fecha
                    : (DateTime?)null; // Validamos la fecha de actuación
                EstadoCheckBox.IsChecked = artistaSeleccionado.Estado; // Estado del artista
                TelefonoTextBox.Text = artistaSeleccionado.Teléfono;

                // Mostramos el festival y el escenario del artista
                FestivalTextBox.Text = artistaSeleccionado.Festival?.Nombre ?? "Sin Festival";
                LugarTextBox.Text = artistaSeleccionado.Escenario?.Nombre ?? "Sin Escenario";

                // Información adicional
                BiografiaTextBox.Text = artistaSeleccionado.Biografía;
                TrayectoriaTextBox.Text = artistaSeleccionado.Trayectoria;
                PremiosTextBox.Text = artistaSeleccionado.Premios;
                IntegrantesTextBox.Text = artistaSeleccionado.Integrantes;
                PeticionesTextBox.Text = artistaSeleccionado.PeticionesEspeciales;

                // Manejo de la imagen del artista
                try
                {
                    // Cargamos la imagen del artista desde la ruta proporcionada
                    ImagenArtista.Source = new BitmapImage(new Uri(artistaSeleccionado.Foto, UriKind.RelativeOrAbsolute));
                }
                catch
                {
                    // En caso de error, no mostramos ninguna imagen
                    ImagenArtista.Source = null;
                }
            }
        }

        // Método para volver a la ventana anterior
        private void Volver_Click(object sender, RoutedEventArgs e)
        {
            // Cierra la ventana actual 
            this.Close();
        }
    }
}

