﻿using System.Windows;

namespace GestionFestivales
{
    public partial class WelcomeWindow : Window
    {
        public WelcomeWindow()
        {
            InitializeComponent();
        }

        private void Comenzar_Click(object sender, RoutedEventArgs e)
        {
            // Abrir la ventana de inicio de sesión
            LoginWindow loginWindow = new LoginWindow();
            loginWindow.Show();
            this.Close();
        }
    }
}
