﻿using System.Collections.Generic;
using System;

namespace GestionFestivales
{
    /// Representa un festival de música, incluyendo información básica, artistas participantes y escenarios asociados.
    public class Festival
    {
        
        /// Nombre del festival.
        public string Nombre { get; set; }

        /// Fecha en la que se celebra el festival.
        public DateTime Fecha { get; set; }

        /// Ubicación donde se celebra el festival.
        public string Ubicacion { get; set; }

        /// Lista de artistas que participan en el festival.
        public List<Artista> Artistas { get; set; } = new List<Artista>();

        /// Lista de escenarios disponibles en el festival.
        public List<Escenario> Escenarios { get; set; } = new List<Escenario>();

        /// Imagen o diseño del cartel anunciador del festival.
        public string CartelAnunciador { get; set; }

        /// Información de redes sociales asociadas al festival (ej.: enlaces a Instagram, Twitter, etc.).
        public string RedesSociales { get; set; }

        /// Precio de las entradas al festival.
        public decimal PrecioEntradas { get; set; }

        /// Edición actual del festival (ej.: "5ª edición", "2025").
        public string Edicion { get; set; }

        /// Enlaces a videos promocionales del festival.
        public string VideosPromocionales { get; set; }

        /// Información sobre los organizadores del festival.
        public string Organizadores { get; set; }

        /// Normas generales para los asistentes del festival.
        public string Normas { get; set; }

        /// Guía de cómo llegar al festival (ej.: transporte público, estacionamientos, etc.).
        public string ComoLlegar { get; set; }

        /// Recomendaciones de lugares para dormir cercanos al festival.
        public string DondeDormir { get; set; }

        /// Estado del festival (ej.: "Planificado", "Pasado", "Cancelado").
        public string Estado { get; set; }

        /// Foto representativa del festival.
        public string Foto { get; set; }
    }
}


