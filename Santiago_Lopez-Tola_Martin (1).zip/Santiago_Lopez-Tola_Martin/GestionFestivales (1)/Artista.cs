﻿namespace GestionFestivales
{
    public class Artista
    {
        public string Nombre { get; set; }
        public string Género { get; set; }
        public string Contacto { get; set; }
        public double Caché { get; set; }
        public string DiaActuación { get; set; }
        public string Foto { get; set; }
        public string Descripción { get; set; }
        public string Ubicación { get; set; }
    }
}

